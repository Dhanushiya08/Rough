// // types/lookup.ts

import type { RequestWithEvent } from "./common";

export type LookupTriggerRequest = RequestWithEvent<
  "lookup-trigger",
  { status: "uploaded" }
>;


export interface LookupItem {
  key: string;
  value: string;
}
